# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: sankey-constructor.spec.js >> captured Sankey construction behavior preserves receiver, defaults, helpers and raw ownership
- Location: tests/web/sankey-constructor.spec.js:4:1

# Error details

```
Error: candidate

expect(received).toEqual(expected) // deep equality

- Expected  - 2
+ Received  + 2

@@ -18,13 +18,13 @@
      "data": true,
      "enumerable": false,
      "writable": false,
    },
    "ownKeys": Array [
-     "length",
-     "name",
      "prototype",
+     "name",
+     "length",
    ],
    "prototype": Object {
      "configurable": false,
      "data": true,
      "enumerable": false,
```

# Page snapshot

```yaml
- generic [active] [ref=e1]:
  - banner [ref=e2]:
    - link "pele-rs" [ref=e3] [cursor=pointer]:
      - /url: https://github.com/vijayksingh/pele-rs
    - generic [ref=e4]: Rust engine · Browser WASM · Swift native
  - main [ref=e5]:
    - region [ref=e6]:
      - heading "One engine. Many diagrams." [level=1] [ref=e7]
      - paragraph [ref=e8]: 33 registered diagram families · five examples below
      - paragraph [ref=e9]: Edit source or change an owned model. Every drawing runs the packed Rust WASM library.
      - generic [ref=e10]:
        - generic [ref=e11]: Example
        - combobox "Example" [ref=e12]:
          - option "Flowchart · capture and review" [selected]
          - option "Class · shared engine"
          - option "Sequence · one render request"
          - option "Pie · editable model"
          - option "Railroad · diagram grammar"
        - generic [ref=e13]: Diagram source
        - textbox "Diagram source" [ref=e14]: "flowchart LR A[Capture] --> B{Keep?} B -->|Yes| C[Review] C --> D[Store] B -->|No| E[Discard] C -.->|Revise| A"
        - generic [ref=e15]:
          - button "Render diagram" [ref=e16] [cursor=pointer]
          - generic [ref=e17]:
            - checkbox "Dark diagram" [ref=e18]
            - text: Dark diagram
        - button "Add Rust slice" [disabled] [ref=e20]
      - status [ref=e21]: flowchart · 566 × 159 · Rust WASM
    - region "Rendered diagram" [ref=e22]:
      - document [ref=e24]:
        - generic [ref=e41]:
          - generic [ref=e42]: "Yes"
          - generic [ref=e44]: "No"
          - generic [ref=e46]: Revise
        - generic [ref=e48]:
          - generic [ref=e49]: Capture
          - generic [ref=e51]: Keep?
          - generic [ref=e53]: Review
          - generic [ref=e55]: Store
          - generic [ref=e57]: Discard
  - contentinfo [ref=e59]: Independent Rust adaptation of Pele 1.6.0 · MIT engine · Example data is illustrative.
```

# Test source

```ts
  1   | import {test,expect} from '@playwright/test';
  2   | import {writeFile} from 'node:fs/promises';
  3   | 
  4   | test('captured Sankey construction behavior preserves receiver, defaults, helpers and raw ownership',async({page},info)=>{
  5   |   await page.goto('/examples/web/');
  6   |   const report=await page.evaluate(async()=>{
  7   |     const {loadRenderer}=await import('/dist/package-web/package/full.js');
  8   |     const {loadDiagramEntries,disposeDiagramModel}=await import('/dist/package-web/package/diagram-entries.js');
  9   |     await loadDiagramEntries();
  10  |     const raw=(await import('/dist/package-web/package/diagrams/sankey.js')).default;
  11  |     const oracle=await import('/dist/evidence/pele-oracle.js');
  12  |     const oracleRaw=(await import('/dist/evidence/pele-esm/diagrams/sankey.js')).default;
  13  |     const engine=await loadRenderer(),seed=engine.parse('sankey\nA,B,1'),referenceSeed=oracle.parse('sankey\nA,B,1');
  14  |     const constructors=[referenceSeed.constructor,seed.constructor],rows=[];
  15  |     const bitsView=new DataView(new ArrayBuffer(8));
  16  |     const bits=value=>{bitsView.setFloat64(0,value);return bitsView.getBigUint64(0).toString(16).padStart(16,'0');};
  17  |     function snapshot(root){
  18  |       const ids=new Map(),objects=[],nodes=[];
  19  |       const atom=value=>{
  20  |         if(value===undefined)return ['undefined'];if(value===null)return ['null'];
  21  |         if(typeof value==='number')return ['number',bits(value)];
  22  |         if(typeof value!=='object')return [typeof value,typeof value==='symbol'?value.description:value];
  23  |         if(!ids.has(value)){ids.set(value,objects.length);objects.push(value);}return ['ref',ids.get(value)];
  24  |       };
  25  |       const rootAtom=atom(root);
  26  |       for(let i=0;i<objects.length;i++){
  27  |         const value=objects[i],properties=Reflect.ownKeys(value).map(key=>{
  28  |           const d=Object.getOwnPropertyDescriptor(value,key);
  29  |           return [key,d.enumerable,d.writable,d.configurable,atom(d.value)];
  30  |         });
  31  |         nodes.push({kind:Array.isArray(value)?'array':value instanceof Map?'map':'object',properties,...(value instanceof Map?{entries:[...value].map(([k,v])=>[atom(k),atom(v)])}:{})});
  32  |       }
  33  |       return {root:rootAtom,nodes};
  34  |     }
  35  |     const error=run=>{try{run();return null;}catch(value){return {name:value.name,message:value.message};}};
  36  |     function constructorMetadata(C){
  37  |       const flags=(object,key)=>{const d=Object.getOwnPropertyDescriptor(object,key);return {data:Object.hasOwn(d,'value'),writable:d.writable,enumerable:d.enumerable,configurable:d.configurable};};
  38  |       return {
  39  |         // Names and engine error text remain unmodified evidence. This feature
  40  |         // does not claim the pending constructor-identity/name catalog.
  41  |         name:C.name,callWithoutNew:error(()=>C()),arity:C.length,
  42  |         intrinsic:{ownKeys:Reflect.ownKeys(C),length:flags(C,'length'),name:flags(C,'name'),prototype:flags(C,'prototype'),prototypeKeys:Reflect.ownKeys(C.prototype),backlink:flags(C.prototype,'constructor'),backlinkIdentity:C.prototype.constructor===C,prototypeIdentity:Object.getOwnPropertyDescriptor(C,'prototype').value===C.prototype,functionParent:Object.getPrototypeOf(C)===Function.prototype,prototypeParent:Object.getPrototypeOf(C.prototype)===Object.prototype}
  43  |       };
  44  |     }
  45  |     const metadata={candidate:constructorMetadata(constructors[1]),oracleCore:constructorMetadata(constructors[0]),oracleEsm:constructorMetadata(oracleRaw.parse('sankey\nA,B,1',{},undefined).constructor)};
  46  |     // A captured constructor must not borrow its original parsed document.
  47  |     engine.dispose(seed);
  48  |     try{
  49  |       for(const mode of ['plain','ignored','subclass','alternate','nullPrototype']){
  50  |         const row={mode};
  51  |         for(const [index,C]of constructors.entries()){
  52  |           const candidate=index===1,trace=[],sentinel={ignored:true};let ignoredReads=0,inheritedWrites=0;
  53  |           const ignored=new Proxy({}, {get(){ignoredReads++;throw sentinel;},ownKeys(){ignoredReads++;throw sentinel;},getPrototypeOf(){ignoredReads++;throw sentinel;}});
  54  |           const args=mode==='ignored'?[ignored,Symbol('ignored'),null,undefined]:[];
  55  |           let model,expectedPrototype;
  56  |           if(mode==='subclass'){
  57  |             class Derived extends C { extra='subclass'; }
  58  |             model=new Derived(...args);expectedPrototype=Derived.prototype;
  59  |           }else if(mode==='alternate'||mode==='nullPrototype'){
  60  |             function Alternate(){}
  61  |             Alternate.prototype=Object.create(mode==='nullPrototype'?null:C.prototype);
  62  |             for(const key of ['type','nodes','links','title','accTitle','accDescr','lookup'])Object.defineProperty(Alternate.prototype,key,{set(){inheritedWrites++;throw sentinel;},configurable:true});
  63  |             model=Reflect.construct(C,args,Alternate);expectedPrototype=Alternate.prototype;
  64  |           }else{model=new C(...args);expectedPrototype=C.prototype;}
  65  |           try{
  66  |             const initial=snapshot(model),roots=[model.nodes,model.links,model.lookup];
  67  |             const draw=()=>{trace.length=0;const options={measurer:{width(text,size,style){trace.push([text,bits(size),style]);return text.length*size*.6;}}};const output=(candidate?raw:oracleRaw).render(model,{},options);return {output,width:bits(output.width),height:bits(output.height),trace:trace.slice()};};
  68  |             const before=error(()=>candidate?engine.render(model):oracle.render(model));
  69  |             const empty=draw();
  70  |             // Borrow from the actual constructor prototype, including an
  71  |             // alternate newTarget whose prototype has no helper inheritance.
  72  |             const a=C.prototype.findOrCreateNode.call(model,'__proto__'),again=C.prototype.findOrCreateNode.call(model,'__proto__');
  73  |             const b=C.prototype.findOrCreateNode.call(model,'B\u{1f642}');
  74  |             const add=C.prototype.addLink.call(model,a,b,5);
  75  |             model.title='Constructed';
  76  |             const populated=draw(),after=error(()=>candidate?engine.render(model):oracle.render(model));
  77  |             const thrown={callback:true};let original=false;
  78  |             try{(candidate?raw:oracleRaw).render(model,{}, {measurer:{width(){model.title='Kept callback title';throw thrown;}}});}catch(value){original=value===thrown;}
  79  |             const recovery=draw();
  80  |             row[candidate?'candidate':'oracle']={initial,empty,populated,recovery,state:snapshot(model),prototype:Object.getPrototypeOf(model)===expectedPrototype,rootsStable:roots[0]===model.nodes&&roots[1]===model.links&&roots[2]===model.lookup,alias:a===again&&a===model.nodes[0]&&model.lookup.get('__proto__')===a&&model.links[0].source===a&&model.links[0].target===b,addUndefined:add===undefined,ignoredReads,inheritedWrites,before,after,original,arity:C.length};
  81  |           }finally{if(candidate)disposeDiagramModel(model);}
  82  |         }
  83  |         rows.push(row);
  84  |       }
  85  |       const callWithoutNew=constructors.map(C=>error(()=>C()).name);
  86  |       // Unimplemented constructors remain explicit, not empty parser models.
  87  |       const other=engine.parse('flowchart TD\nA-->B');let unsupported;
  88  |       try{unsupported=error(()=>new other.constructor());}finally{engine.dispose(other);}
  89  |       return {rows,callWithoutNew,metadata,unsupported};
  90  |     }finally{engine.close();}
  91  |   });
  92  |   const path=info.outputPath('sankey-constructor.json');await writeFile(path,JSON.stringify(report,null,2));await info.attach('sankey-constructor.json',{path,contentType:'application/json'});
  93  |   expect(report.callWithoutNew).toEqual(['TypeError','TypeError']);
  94  |   for(const [lane,metadata]of Object.entries(report.metadata)){
  95  |     expect(metadata.arity,lane).toBe(0);
  96  |     expect(metadata.callWithoutNew.name,lane).toBe('TypeError');
> 97  |     expect(metadata.intrinsic,lane).toEqual({
      |                                     ^ Error: candidate
  98  |       ownKeys:['length','name','prototype'],
  99  |       length:{data:true,writable:false,enumerable:false,configurable:true},
  100 |       name:{data:true,writable:false,enumerable:false,configurable:true},
  101 |       prototype:{data:true,writable:false,enumerable:false,configurable:false},
  102 |       prototypeKeys:['constructor','findOrCreateNode','addLink'],
  103 |       backlink:{data:true,writable:true,enumerable:false,configurable:true},
  104 |       backlinkIdentity:true,prototypeIdentity:true,functionParent:true,prototypeParent:true
  105 |     });
  106 |   }
  107 |   // Known name and non-new message gaps are retained in the attached raw report,
  108 |   // not normalized or asserted equal to the oracle.
  109 |   expect(report.unsupported).toEqual({name:'TypeError',message:'Public model construction is unavailable'});
  110 |   expect(report.rows).toHaveLength(5);
  111 |   for(const row of report.rows){
  112 |     expect(row.candidate,row.mode).toEqual(row.oracle);
  113 |     expect(row.candidate,row.mode).toMatchObject({prototype:true,rootsStable:true,alias:true,addUndefined:true,ignoredReads:0,inheritedWrites:0,original:true,arity:0,before:{name:'TypeError',message:'render() takes diagram text or a model that parse() returned.'},after:{name:'TypeError',message:'render() takes diagram text or a model that parse() returned.'}});
  114 |   }
  115 | });
  116 | 
  117 | test('Sankey constructors retain captured registrations across replacement, close and disposal',async({page})=>{
  118 |   await page.goto('/examples/web/');
  119 |   const report=await page.evaluate(async()=>{
  120 |     const {loadRegistry}=await import('/dist/package-web/package/registry.js');
  121 |     const {loadDiagramEntries,disposeDiagramModel}=await import('/dist/package-web/package/diagram-entries.js');
  122 |     await loadDiagramEntries();
  123 |     const raw=(await import('/dist/package-web/package/diagrams/sankey.js')).default,oracleRaw=(await import('/dist/evidence/pele-esm/diagrams/sankey.js')).default;
  124 |     const oracle=await import('/dist/evidence/pele-oracle.js'),reference=oracle.parse('sankey\nA,B,1'),Expected=reference.constructor;
  125 |     const a=await loadRegistry(),b=await loadRegistry();a.register(raw);b.register(raw);
  126 |     const seedA=a.parse('sankey\nA,B,1'),seedB=b.parse('sankey\nX,Y,2'),A=seedA.constructor,B=seedB.constructor;
  127 |     a.dispose(seedA);b.dispose(seedB);
  128 |     // A foreign replacement cannot become the previously captured factory.
  129 |     a.register({type:'sankey',parse(){throw new Error('Replacement parse');},render(){throw new Error('Replacement render');}});
  130 |     a.close();b.close();
  131 |     const checks=[],rows=[],models=[];
  132 |     const options={measurer:{width(text,size){return text.length*size*.6;}}};
  133 |     try{
  134 |       for(const C of [A,B]){
  135 |         const model=new C(Symbol('ignored')),expected=new Expected();models.push(model);
  136 |         const first=model.findOrCreateNode('First'),target=model.findOrCreateNode('Last');model.addLink(first,target,3);
  137 |         const x=expected.findOrCreateNode('First'),y=expected.findOrCreateNode('Last');expected.addLink(x,y,3);
  138 |         rows.push({actual:raw.render(model,{},options),expected:oracleRaw.render(expected,{},options)});
  139 |         checks.push(first===model.nodes[0]&&model.lookup.get('First')===first&&model.links[0].source===first);
  140 |       }
  141 |       // Plain foreign receivers use the live captured constructor owner.
  142 |       const plain={type:'sankey',nodes:[],links:[],lookup:new Map()},expectedPlain={type:'sankey',nodes:[],links:[],lookup:new Map()};
  143 |       const added=A.prototype.findOrCreateNode.call(plain,'Borrowed'),wanted=Expected.prototype.findOrCreateNode.call(expectedPlain,'Borrowed');
  144 |       checks.push(added===plain.nodes[0]&&plain.lookup.get('Borrowed')===added&&JSON.stringify(added)===JSON.stringify(wanted));
  145 |       const kept=models[0],helper=kept.findOrCreateNode;
  146 |       disposeDiagramModel(kept);
  147 |       let disposed;try{raw.render(kept,{},options);}catch(error){disposed={name:error.name,message:error.message};}
  148 |       // A new factory invocation stays independent of that disposed owner.
  149 |       const fresh=new A();models.push(fresh);checks.push(fresh.findOrCreateNode('Fresh')===fresh.nodes[0]);
  150 |       const borrowed=helper.call(fresh,'After disposal');checks.push(borrowed===fresh.nodes[1]&&fresh.lookup.get('After disposal')===borrowed);
  151 |       return {rows,checks,disposed};
  152 |     }finally{for(const model of models)disposeDiagramModel(model);a.close();b.close();}
  153 |   });
  154 |   expect(report.checks).toEqual(Array(5).fill(true));
  155 |   expect(report.disposed).toEqual({name:'TypeError',message:'Public model document is disposed'});
  156 |   for(const row of report.rows)expect(row.actual).toEqual(row.expected);
  157 | });
  158 | 
```