// Explicitly authorized one-shot scheduler. No builds, waits for quiet, retries or pooling.
import assert from 'node:assert/strict';
import {readFile,writeFile,mkdir,open} from 'node:fs/promises';
import {spawn} from 'node:child_process';
import {resolve} from 'node:path';
import {fileURLToPath} from 'node:url';
import {performance} from 'node:perf_hooks';
import {guardQuiet,inputs,sha,systemProcesses} from '../../../../scripts/perf/swift/build.mjs';
assert.deepEqual(process.argv.slice(2),['--parent-go'],'Run only after explicit parent go; do not start from log completion alone');
const root=process.cwd(),base='dist/perf-patches/parse-architecture/native-canonical-swift-timing';
const output=base+'/attempt1';
await mkdir(output); // Exclusive attempt directory: existing evidence must never be overwritten.
const started=performance.now(),deadline=started+180_000;
const report={schemaVersion:1,startedAt:new Date().toISOString(),budgetMs:180_000,strictGuardUnchanged:true,retries:0,pooling:false,case:'sankey/medium',stages:['parseMutable','parse','render','lifetime'],trialsPerCondition:15,warmupMsPerSide:1000,conditions:[],acceptedConditions:[],unmeasuredConditions:[]};
const save=()=>writeFile(output+'/schedule.json',JSON.stringify(report,null,2)+'\n');
const controlDir='dist/perf-patches/parse-architecture/captured-native-core/candidate-swift';
const candidateDir='dist/perf-patches/parse-architecture/native-canonical-correctness/candidate-swift';
const candidateManifestPath=candidateDir+'/swift-build-manifest.json';
let currentCondition;
try {
 report.authorization='Parent explicit GO for one bounded default-native Swift comparison: frozen25d87cb control versus fresh3166b3d candidate.362 native/consumer/SDK inputs remain identical through JS-only cursor5db9f35. No opt-in WASM performance claim.';
 report.schedulerSha256=sha(await readFile(fileURLToPath(import.meta.url)));
 report.comparatorSha256=sha(await readFile('scripts/perf/swift/compare.mjs'));
 report.guardModuleSha256=sha(await readFile('scripts/perf/swift/build.mjs'));
 const pinned=JSON.parse(await readFile(base+'/prepared-manifest.json','utf8'));
 assert.equal(report.schedulerSha256,pinned.schedulerSha256);assert.equal(report.comparatorSha256,pinned.comparatorSha256);assert.equal(report.guardModuleSha256,pinned.guardModuleSha256);
 report.continuitySha256=sha(await readFile(base+'/swift-input-continuity.json'));assert.equal(report.continuitySha256,pinned.continuitySha256);
 report.hostProcessesBefore=systemProcesses();
 guardQuiet(); // Any compiler, even CPU0, or Pele xctest ends this attempt immediately.
 const manifest=JSON.parse(await readFile(candidateManifestPath,'utf8'));
 const control=JSON.parse(await readFile(controlDir+'/swift-build-manifest.json','utf8'));
 assert.equal(manifest.sourceInputSha256,'1f89890b534bf1fe2958ed9b03bbc91470cae260a615925e1b15df752cb157ee');
 assert.equal(manifest.binarySha256,'c9fb8ab770594cf4395d0f035f8f7cc0f56cf98641a6a5c74b2ee623ec66082a');
 assert.equal(control.binarySha256,'9c1d267539a7eaa1b94243dc64cc1dabfafbd0c795a73dd265d5b3f843d56888');
 assert.equal(sha(await readFile(candidateDir+'/PeleSwiftPerf')),manifest.binarySha256);
 assert.equal(sha(await readFile(manifest.binary)),manifest.binarySha256);
 assert.equal(sha(await readFile(controlDir+'/PeleSwiftPerf')),control.binarySha256);
 assert.equal(sha(await readFile(candidateManifestPath)),pinned.candidate.manifestSha256);assert.equal(sha(await readFile(controlDir+'/swift-build-manifest.json')),pinned.control.manifestSha256);
 assert.equal(manifest.revision,'3166b3dd18569ad0bc20f173a8941dd628609ddc');assert.equal(control.revision,'25d87cb49bb451d3e7c1e70c2856ccb6fef4abd0');
 const before=await inputs(root);assert.equal(before.sha256,manifest.sourceInputSha256);assert.equal(Object.keys(before.files).length,362);assert.deepEqual(before.files,manifest.inputHashes);
 await writeFile(output+'/source-before.json',JSON.stringify(before,null,2)+'\n',{flag:'wx'});
 report.frozen={sourceInputSha256:before.sha256,candidateBinarySha256:manifest.binarySha256,controlBinarySha256:control.binarySha256,candidateManifestSha256:sha(await readFile(candidateManifestPath)),controlManifestSha256:sha(await readFile(controlDir+'/swift-build-manifest.json'))};
 await save();
 for(const [index,stage] of report.stages.entries()) {
  if(performance.now()>=deadline)throw Error('Overall180-second budget exhausted before next condition');
  guardQuiet();
  const target=output+'/'+stage+'.json',logPath=output+'/'+stage+'.log';
  currentCondition={stage,orderOffset:index%2,startedAt:new Date().toISOString(),output:target,log:logPath};
  report.conditions.push(currentCondition);
  const args=['scripts/perf/swift/compare.mjs','--quiet-run','--control-dir',controlDir,'--candidate-manifest',candidateManifestPath,'--cases','sankey/medium','--stages',stage,'--order-offset',String(index%2),'--output',target];
  currentCondition.command=[process.execPath,...args];await save();
  const log=await open(logPath,'wx');let child,timer,timedOut=false;
  try {
   const remaining=deadline-performance.now();assert(remaining>0,'Overall180-second budget exhausted');
   const result=await new Promise((resolve,reject)=>{
    child=spawn(process.execPath,args,{cwd:root,detached:true,stdio:['ignore',log.fd,log.fd]});
    timer=setTimeout(()=>{timedOut=true;try{process.kill(-child.pid,'SIGKILL')}catch(e){if(e.code!=='ESRCH')reject(e)}},remaining);
    child.on('error',reject);child.on('exit',(code,signal)=>resolve({code,signal}));
   });
   currentCondition.exitCode=result.code;currentCondition.signal=result.signal;
  } finally {clearTimeout(timer);await log.close()}
  currentCondition.completedAt=new Date().toISOString();currentCondition.timedOut=timedOut;
  if(timedOut)throw Error('Overall180-second budget exhausted; condition rejected');
  if(currentCondition.exitCode!==0)throw Error('Condition failed or strict guard rejected; no retry: '+stage);
  guardQuiet();
  const data=JSON.parse(await readFile(target,'utf8'));
  assert.equal(data.completed,true);assert.equal(data.rows.length,1);assert.equal(data.rows[0].raw.length,15);
  assert.equal(data.rows[0].case,'sankey/medium');assert.equal(data.rows[0].stage,stage);
  assert.equal(data.settings.trials,15);assert.equal(data.settings.warmupMsPerBinaryPerStage,1000);assert.equal(data.settings.orderOffset,index%2);
  for(const side of ['control','candidate'])assert(data.rows[0].warmup[side].elapsedNs>=1_000_000_000);
  currentCondition.orderCounts=data.orderCounts;
  currentCondition.accepted=true;currentCondition.reportSha256=sha(await readFile(target));report.acceptedConditions.push(stage);
  await save();console.log('Accepted complete condition '+stage);
 }
 const after=await inputs(root);assert.equal(after.sha256,report.frozen.sourceInputSha256);
 assert.deepEqual(after,before);await writeFile(output+'/source-after.json',JSON.stringify(after,null,2)+'\n',{flag:'wx'});
 assert.equal(sha(await readFile(candidateManifestPath)),report.frozen.candidateManifestSha256);assert.equal(sha(await readFile(controlDir+'/swift-build-manifest.json')),report.frozen.controlManifestSha256);
 report.acceptedOrderCounts=report.conditions.filter(c=>c.accepted).reduce((sum,c)=>({control:sum.control+c.orderCounts.control,candidate:sum.candidate+c.orderCounts.candidate}),{control:0,candidate:0});
 assert.deepEqual(report.acceptedOrderCounts,{control:30,candidate:30});
 assert.equal(sha(await readFile(manifest.binary)),report.frozen.candidateBinarySha256);
 assert.equal(sha(await readFile(candidateDir+'/PeleSwiftPerf')),report.frozen.candidateBinarySha256);
 assert.equal(sha(await readFile(controlDir+'/PeleSwiftPerf')),report.frozen.controlBinarySha256);
 guardQuiet();report.succeeded=true;report.completedAt=new Date().toISOString();
} catch(error) {
 report.succeeded=false;report.failedAt=new Date().toISOString();report.error=String(error);
 if(currentCondition&&!currentCondition.accepted)currentCondition.rejected=true;
 process.exitCode=1;
} finally {
 report.unmeasuredConditions=report.stages.filter(stage=>!report.acceptedConditions.includes(stage));
 report.elapsedWallMs=performance.now()-started;report.hostProcessesAfter=systemProcesses();await save();
 console.log(JSON.stringify({succeeded:report.succeeded,acceptedConditions:report.acceptedConditions,unmeasuredConditions:report.unmeasuredConditions,error:report.error,elapsedWallMs:report.elapsedWallMs}));
}
