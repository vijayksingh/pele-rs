"""Read existing evidence only. No consumers, builds, browsers or timers."""
from pathlib import Path
import hashlib,json,math,statistics
ROOT=Path(__file__).resolve().parents[4]
HERE=Path(__file__).resolve().parent
BENCH=ROOT/'dist/perf-patches/parse-architecture/er-raw-host/benchmark'
def read(path): return json.loads(path.read_text())
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def tree(path): return {str(p.relative_to(path)):sha(p) for p in sorted(path.rglob('*')) if p.is_file()}
def close(a,b): assert math.isclose(a,b,rel_tol=1e-12,abs_tol=1e-12),(a,b)
def quantile(v,p): return sorted(v)[max(0,math.ceil(len(v)*p)-1)]
def order(t):
 names=['js','control','candidate'];x=names[t%3:]+names[:t%3]
 return x[::-1] if (t//3)%2 else x
raw=read(HERE/'raw-comparison.json');freeze=read(HERE/'raw-inputs.json');ordinary=read(HERE/'ordinary-comparison.json')
assert raw['succeeded'] and ordinary['succeeded'];assert len(raw['rows'])==18 and len(ordinary['rows'])==12
assert raw['inputManifestSHA256']==sha(HERE/'raw-inputs.json');assert raw['inputHashes']==freeze['hashes']
assert raw['inputHashes']['controlProofSHA256']==sha(HERE/'ordinary-comparison.json')
assert raw['runtimeHashes']==ordinary['runtimeHashes'];assert all(len(v)==106 for v in raw['runtimeHashes'].values())
assert raw['runtimeHashes']['candidate']==tree(ROOT/'dist/package-web/package')
for name,value in raw['inputHashes']['harness'].items():assert sha(BENCH/name)==value
assert sha(ROOT/'scripts/perf/cases.mjs')==raw['inputHashes']['casesSHA256']==ordinary['casesSHA256']
assert sha(ROOT/'scripts/perf/swift/build.mjs')==raw['inputHashes']['guardSHA256']
assert sha(ROOT/'scripts/perf/compare-web-vm.mjs')==ordinary['harnessSHA256']
assert sha(ROOT/'node_modules/pele/dist/pele.js')==raw['inputHashes']['oracleBundleSHA256']==ordinary['oracleSHA256']=='d1ebc1889f3069d7759fe5db34c4ad4b4823285edbee2b537d0ef3d505a76d8d'
assert raw['oracleHashes']==raw['inputHashes']['packages']['oracle']==tree(ROOT/'node_modules/pele/dist/esm')==read(BENCH/'oracle-pins.json')['files']
assert raw['runtimeHashes']['control']==raw['inputHashes']['packages']['control'];assert raw['runtimeHashes']['candidate']==raw['inputHashes']['packages']['candidate']
assert len(raw['guards'])==18;assert raw['clock']['crossOriginIsolated'] and 0<raw['clock']['resolutionMs']<=.01
assert raw['settings']['trials']==15 and raw['settings']['warmupMs']==1000
assert ordinary['settings']['trials']==9 and ordinary['settings']['warmupMs']==500
summaries={};checks={};pair_order={'controlFirst':0,'candidateFirst':0};raw_pairs=0
sources={}
for scale,n in [('small',8),('medium',48),('large',200)]:
 source='erDiagram\n'+'\n'.join(f'E{i} {{\n int id PK\n string label\n}}' for i in range(n))+'\n'+'\n'.join(f'E{i} ||--o{{ E{i+1} : owns' for i in range(n-1))
 sources['er/'+scale]=(hashlib.sha256(source.encode()).hexdigest(),len(source.encode()))
for label,report,trials,warmup in [('raw',raw,15,1000),('ordinary',ordinary,9,500)]:
 rows=[];seen=set()
 for index,r in enumerate(report['rows']):
  key=(r['case'],r['profile'],r['stage']);assert key not in seen;seen.add(key)
  samples=r['samples'];assert all(len(samples[name])==trials for name in ['js','control','candidate'])
  for name,values in samples.items():
   assert all(math.isfinite(x) and x>0 for x in values);close(r['medianMs'][name],quantile(values,.5));close(r['p95BatchMeanMs'][name],quantile(values,.95))
   assert r['warmups'][name]['operations']>=6 and r['warmups'][name]['elapsedMs']>=warmup
  close(r['candidateOverControl'],r['medianMs']['candidate']/r['medianMs']['control']);close(r['candidateOverJS'],r['medianMs']['candidate']/r['medianMs']['js']);close(r['controlOverJS'],r['medianMs']['control']/r['medianMs']['js'])
  ratios=[b/a for a,b in zip(samples['control'],samples['candidate'])];wins=sum(x<1 for x in ratios);paired=(quantile(ratios,.5)-1)*100
  if label=='raw':
   assert (r['sourceSHA256'],r['sourceBytes'])==sources[r['case']];assert len(r['raw'])==trials
   count=r['count'];assert count in [1,2,4,8,16,32,64,128]
   assert count==min(c['count'] for c in r['calibration'].values())
   for c in r['calibration'].values():
    assert c['probes'][-1]['count']==c['count']
    for i,p in enumerate(c['probes']):assert p['count']==2**i and len(p['ms'])==3
    for p in c['probes'][:-1]:assert quantile(p['ms'],.5)<12
    assert c['count']==128 or quantile(c['probes'][-1]['ms'],.5)>=12
   first={name:0 for name in samples}
   for t,triple in enumerate(r['raw']):
    assert triple['trial']==t and triple['order']==order(t) and triple['count']==count
    first[triple['order'][0]]+=1
    pair_order['controlFirst' if triple['order'].index('control')<triple['order'].index('candidate') else 'candidateFirst']+=1
    for name in samples:close(triple['elapsedMs'][name]/count,samples[name][t])
   assert set(first.values())=={5};raw_pairs+=trials
   assert ratios==r['paired']['ratios'];close(paired,r['paired']['medianPercentChange']);close(quantile(ratios,.5),r['paired']['medianRatio']);assert wins==r['paired']['candidateWins']
   c=r['correctness'];assert c['beforeAndAfter'] and c['completeOutput'] and c['descriptorsAndAliases']
   assert c['fixtureSha256']==c['firstStateSha256']==c['repeatStateSha256'];assert c['firstSvgSha256']==c['repeatSvgSha256']
   for name in ['fixtureSha256','firstSvgSha256','repeatSvgSha256','firstStateSha256','repeatStateSha256']:assert len(c[name])==64
   group=(r['case'],r['profile']);assert group not in checks or checks[group]==c;checks[group]=c
   assert tuple(raw['guards'][index][name] for name in ['case','profile','stage'])==key
  else:
   assert r['counts']['control']==r['counts']['candidate'];assert all(x in [1,2,4,8,16,32,64,128] for x in r['counts'].values())
  rows.append({'case':r['case'],'profile':r['profile'],'stage':r['stage'],'controlMedianMs':r['medianMs']['control'],'candidateMedianMs':r['medianMs']['candidate'],'ratioOfMediansPercentChange':100*(r['candidateOverControl']-1),'medianPairedPercentChange':paired,'candidatePairWins':wins,'trials':trials,'candidateOverJS':r['candidateOverJS']})
 summaries[label]=rows
for c in ordinary['cases']:assert (c['sourceSHA256'],c['sourceBytes'])==sources[c['id']]
# Locate an optional local mirror without claiming report cross-checks prove bytes.
control_candidates=[HERE/'control-package',HERE/'parse-architecture/er-prepared-host-first/package',ROOT/'dist/perf-patches/parse-architecture/er-prepared-host-first/package']
mirror=next((p for p in control_candidates if p.is_dir()),None)
if mirror:assert tree(mirror)==raw['runtimeHashes']['control']
out={'status':'read-only audit passed','reportSHA256':{n:sha(HERE/n) for n in ['raw-comparison.json','raw-inputs.json','ordinary-comparison.json']},'verified':{'candidatePackageFilesFromDisk':106,'controlPackageHashesCrossReports':106,'controlPackageMirror':str(mirror) if mirror else None,'oracleEsmFilesFromDisk':len(raw['oracleHashes']),'harnessAndCasesAndGuardCurrent':True,'rawRows':18,'rawPairedTrials':raw_pairs,'rawRelativeOrder':pair_order,'rawFirstPositionPerLanePerRow':5,'rawCorrectnessGroups':len(checks),'ordinaryRows':12,'ordinaryPairedTrials':108,'ordinaryOrder':'reconstructed from hash-verified deterministic harness; raw order not emitted'},'packageFilesChanged':[k for k in raw['runtimeHashes']['candidate'] if raw['runtimeHashes']['candidate'][k]!=raw['runtimeHashes']['control'].get(k)],'limits':['Control actual bytes not independently read unless optional mirror path is present.','Raw report retains hashes and successful comparison flags, not full SVG/model values; exactness is established by hash-bound executed assertions, not independently replayed.','Ordinary report emits only SVG byte count/dimensions checks, no full outputs or trial order.','Guard rejects builds/tests and initial browsers but does not guarantee host exclusivity; sampled high CPU data remains contextual.','15 or 9 serial batch means do not establish confidence intervals or causal stage attribution.'],'summaries':summaries}
(HERE/'audit.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out['verified'],indent=2))
