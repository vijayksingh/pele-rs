# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: additional-diagrams.spec.js >> class pinned corpus through WASM source and owned model APIs
- Location: tests/web/additional-diagrams.spec.js:4:3

# Error details

```
Error: page.evaluate: Test ended.
```

# Test source

```ts
  1   | import {test,expect} from '@playwright/test';
  2   | 
  3   | for(const family of ['packet','radar','quadrant','timeline','journey','flowchart','kanban','mindmap','class','er','xychart','state','gantt','sequence','git-graph','architecture','sankey','treemap','c4','info','requirement','block','railroad','cynefin','treeview','agentflow','wardley','eventmodeling','usecase','venn','ishikawa','swimlane']) {
  4   |   test(`${family} pinned corpus through WASM source and owned model APIs`, async({page})=>{
  5   |     test.setTimeout(120_000);
  6   |     await page.goto('/examples/web/');
> 7   |     const report=await page.evaluate(async family=>{
      |                             ^ Error: page.evaluate: Test ended.
  8   |       const {loadRenderer,metricsMeasurer}=await import('/dist/package-web/package/full.js');
  9   |       const wasm=await import('/dist/package-web/package/pkg/pele.js');
  10  |       const historicalProjectionFamilies=new Set(['gantt','sequence','c4','requirement','block','railroad','venn']);
  11  |       const engine=await loadRenderer(), fixture=await(await fetch(`/fixtures/pele/${family}.json`)).json();
  12  |       const publicType=family==='treeview'?'treeView':family==='git-graph'?'gitGraph':family;
  13  |       const canonical=value=>JSON.stringify(value,(_,v)=>v instanceof Map?[...v]:v&&typeof v==='object'&&!Array.isArray(v)?Object.fromEntries(Object.entries(v).sort(([a],[b])=>a.localeCompare(b))):v);
  14  |       const mismatches=[];
  15  |       const oracle=family==='gantt'?await import('/dist/evidence/pele-oracle.js'):null;
  16  |       let runtimeDateCases=0, flatProjectionCases=0, transportBoundaryCases=0, binaryStyleCases=0, immutableProjectionCases=0, nativeOutputBoundaryCases=0;
  17  |       // The old corpus omits this declared private lookup. Raw public ownership
  18  |       // and alias identity have their own mutable-model E2E proof.
  19  |       const comparedModel=model=>{
  20  |         const omitted=model?.type==='sankey'?['lookup']:model?.type==='flowchart'?['subgraphLookup','members','edgeById','pairCount','subCount','options']:model?.type==='er'?['subgraphLookup','claimed']:model?.type==='agentflow'?['subgraphLookup','globalNodes','members','edgeById','pairCount','subCount','bareMappings','firstMapping','reported','options']:model?.type==='state'?['dividerCount']:model?.type==='ishikawa'?['stack','baseLevel']:[];
  21  |         const view=omitted.length?Object.fromEntries(Object.entries(model).filter(([key])=>!omitted.includes(key))):model;
  22  |         if(model?.type==='state')view.direction=model.direction;
  23  |         return view;
  24  |       };
  25  |       for(const c of fixture.cases) {
  26  |         let actual,model,semanticModel,historicalModel,projectionBounded=false;
  27  |         const host=c.host??{},options={...c.options,measurer:host.measure==='fixed'?{width:(text,size,style)=>text.length*size*(style&1?.71:.6)}:metricsMeasurer,...(host.allIcons?{icons:()=>'<path d="M0,0"/>'}:host.icons?{icons:n=>Object.hasOwn(host.icons,n)&&typeof host.icons[n]==='string'?host.icons[n]:undefined}:{})};
  28  |         const classTransportBoundaries={
  29  |           'stress/namespace name of 12,000 parts':'046702029bd9c44c84e60976877b377f08f77f0f4a874cde27c3985b9b232bc5',
  30  |           'stress/4,000 nested namespaces':'56424df5324ecd9871e81aa3b3e06e3f8504a0fd521cc162e4330a725e13ffa0'
  31  |         };
  32  |         if(family==='class'&&Object.hasOwn(classTransportBoundaries,c.id)){
  33  |           const bytes=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(c.source));
  34  |           const hash=[...new Uint8Array(bytes)].map(v=>v.toString(16).padStart(2,'0')).join('');
  35  |           if(hash!==classTransportBoundaries[c.id])mismatches.push(c.id+': boundary source hash');
  36  |           const errorValue=e=>({name:e.name,message:e.message,code:e.code,type:e.type,line:e.line,column:e.column,snippet:e.snippet});
  37  |           let nativeError,sourceError,unexpectedModel;
  38  |           try{unexpectedModel=engine.parse(c.source,c.options)}catch(e){nativeError=errorValue(e)}finally{if(unexpectedModel)engine.dispose(unexpectedModel)}
  39  |           try{engine.render(c.source,options)}catch(e){sourceError=errorValue(e)}
  40  |           if(canonical(nativeError)!==canonical({name:'PeleError',message:'Public model graph exceeds work budget',code:'limit',type:null,line:0,column:0,snippet:''}))mismatches.push(c.id+': native transport boundary');
  41  |           if(c.id==='stress/namespace name of 12,000 parts') {
  42  |             // This exact SHA-pinned vector has >64 MiB of proven emitted IDs.
  43  |             // Keep the pinned 4M semantic error and native byte ceiling distinct.
  44  |             const pinned={name:'PeleError',message:'Diagram output is longer than the limit of 4000000 characters.',code:'limit',type:'class',line:0,column:0,snippet:''};
  45  |             const native={name:'PeleError',message:'Native render output exceeds byte budget',code:'limit',type:'class',line:0,column:0,snippet:''};
  46  |             if(canonical(c.expected.error)!==canonical(pinned))mismatches.push(c.id+': pinned semantic boundary');
  47  |             if(canonical(sourceError)!==canonical(native))mismatches.push(c.id+': native output byte boundary');
  48  |             nativeOutputBoundaryCases++;
  49  |           } else if(canonical(sourceError)!==canonical(c.expected.error))mismatches.push(c.id+': source error');
  50  |           transportBoundaryCases++;
  51  |           continue;
  52  |         }
  53  |         let expected={...c.expected};
  54  |         // Diagnostic provenance is not part of the public parse/render envelope.
  55  |         delete expected.upstreamModelSha256;
  56  |         delete expected.projectionBudget;
  57  |         // Date.parse is a host resource. Compare divergent legacy inputs against
  58  |         // the pinned upstream library in this same browser, without fixture injection.
  59  |         if(oracle&&Object.entries(host.oracleDateParse??{}).some(([text,value])=>{
  60  |           const parsed=Date.parse(text);return (Number.isFinite(parsed)?parsed:null)!==value;
  61  |         })) {
  62  |           runtimeDateCases++;
  63  |           let oracleModel;
  64  |           try {
  65  |             const parsed=oracle.parse(c.source,c.options);
  66  |             oracleModel=JSON.parse(JSON.stringify(parsed,(_,v)=>v instanceof Map?[...v]:v));
  67  |             expected={model:oracleModel,result:oracle.render(parsed,options)};
  68  |           } catch(e) {expected={...(oracleModel?{model:oracleModel}:{}),error:{name:e.name,message:e.message,code:e.code,type:e.type,line:e.line,column:e.column,snippet:e.snippet}};}
  69  |         }
  70  |         try {
  71  |           if((host.modelProjection==='excluded'||expected.modelProjectionLimit)) {
  72  |             let bounded=false, projected;
  73  |             try {projected=engine.parse(c.source,c.options)} catch(e){bounded=e.code==='limit'&&e.type===publicType}
  74  |             if(family==='class'&&['stress/1,600 classDefs applied to 1,600 classes','stress/a classDef of 5,000 declarations on 800 classes, each with a style of its own'].includes(c.id)){
  75  |               if(!projected)mismatches.push(c.id+': valid model must cross binary transport');
  76  |               else binaryStyleCases++;
  77  |             }
  78  |             projectionBounded=bounded||!!projected;
  79  |             if(!projectionBounded)mismatches.push(`${c.id}: projection failed outside declared bounds`);
  80  |             let rendered;
  81  |             try {
  82  |               if(projected) {
  83  |                 flatProjectionCases++;
  84  |                 rendered=engine.render(projected,options);
  85  |                 if(canonical(rendered)!==canonical(engine.render(c.source,options)))mismatches.push(`${c.id}: flat/source differ`);
  86  |               } else rendered=engine.render(c.source,options);
  87  |             } finally {if(projected)engine.dispose(projected)}
  88  |             actual={...(expected.modelProjectionLimit?{modelProjectionLimit:true}:{}),result:rendered};
  89  |           } else {
  90  |             model=engine.parse(c.source,c.options);
  91  |             if(historicalProjectionFamilies.has(family)) {
  92  |               // The historical corpus pins the immutable typed JSON projection.
  93  |               // The actual mutable object exposes additional private own fields,
  94  |               // and Gantt rendering schedules in place. Check both contracts via
  95  |               // their real native APIs instead of stripping public model fields.
  96  |               const immutable=wasm.parse_v2(c.source,JSON.stringify(c.options??{}));
  97  |               try {
  98  |                 const envelope=JSON.parse(immutable.model());
  99  |                 if(!envelope.ok)throw Object.assign(new Error(envelope.error.message),envelope.error);
  100 |                 historicalModel=envelope.result.model;
  101 |                 immutableProjectionCases++;
  102 |               } finally {immutable.free();}
  103 |             }
  104 |             semanticModel=expected.semanticModel?engine.query(model,"semanticModel"):undefined;
  105 |             actual={model:historicalModel??comparedModel(model),...(semanticModel!==undefined?{semanticModel}:{}),result:engine.render(model,options)};
  106 |           }
  107 |           if(!(host.modelProjection==='excluded'||expected.modelProjectionLimit)&&canonical(actual.result)!==canonical(engine.render(c.source,options)))mismatches.push(`${c.id}: source/model differ`);
```