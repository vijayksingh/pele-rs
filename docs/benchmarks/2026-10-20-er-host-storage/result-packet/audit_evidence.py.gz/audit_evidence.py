#!/usr/bin/env python3
"""Read frozen evidence and Git objects only; no consumers/builds/benchmarks."""
from pathlib import Path
import json,gzip,hashlib,subprocess,statistics,collections
root=Path(__file__).resolve().parents[4]
r=root/'docs/benchmarks/2026-10-20-er-host-storage/result-packet'
read=lambda p:json.loads(p.read_text());sha=lambda b:hashlib.sha256(b).hexdigest()
index=read(r/'evidence-index.json');freeze=read(r/'source-freeze.json');report=read(r/'comparison.json');raw=read(r.parent/'raw/raw-comparison.json');sdk=read(r.parent/'raw/swift-build-manifest.json');summary=read(r/'paired-summary.json')
for x in index['records']:
 b=(r/x['path']).read_bytes();assert sha(b)==x['archiveSha256'];assert sha(gzip.decompress(b) if x['path'].endswith('.gz') else b)==x['sourceSha256']
assert report['runtimeHashes']['candidate']==freeze['packageFiles']
assert report['runtimeHashes']['control']==raw['runtimeHashes']['candidate']
assert len(freeze['packageFiles'])==len(report['runtimeHashes']['control'])==106
assert {k:v for k,v in freeze['sourceFiles'].items() if not k.startswith('web/')}==sdk['inputHashes']
assert freeze['nativeSourceInputSha256']==sdk['sourceInputSha256']
matched=0
for k,h in freeze['sourceFiles'].items():
 prefix,p=k.split('/',1)
 if prefix=='CPele':continue
 if prefix=='consumer':p='scripts/perf/swift/'+p
 b=subprocess.check_output(['git','show',freeze['sourceCommit']+':'+p],cwd=root)
 assert sha(b)==h,(k,sha(b),h);matched+=1
for key,p in [('harnessSHA256','scripts/perf/compare-web-vm.mjs'),('casesSHA256','scripts/perf/cases.mjs')]:
 assert sha(subprocess.check_output(['git','show',freeze['sourceCommit']+':'+p],cwd=root))==report[key]
assert report['succeeded'] and report['completedAt'];assert len(report['rows'])==24
keys={(x['case'],x['profile'],x['stage']) for x in report['rows']}
expected={(c,p,s) for c in ['sequence/small','er/small','er/medium','er/large'] for p in ['fixed','canvas'] for s in ['parse','render-model','render-source']};assert keys==expected
calc=[]
for row in report['rows']:
 assert row['counts']['candidate']==row['counts']['control']
 for lane in ['js','control','candidate']:
  assert len(row['samples'][lane])==21
  assert statistics.median(row['samples'][lane])==row['medianMs'][lane]
  assert row['warmups'][lane]['elapsedMs']>=1000
 ratio=[a/b for a,b in zip(row['samples']['candidate'],row['samples']['control'])]
 item=next(x for x in summary if all(x[k]==row[k] for k in ['case','profile','stage']))
 assert abs(item['pairedMedianPercentChange']-(statistics.median(ratio)-1)*100)<1e-9
 assert item['candidateWins']==sum(x<1 for x in ratio)
 assert item['candidateOverJS']==row['medianMs']['candidate']/row['medianMs']['js']
 calc.append(item)
engines=[]
for engine in ['chromium','firefox','webkit']:
 paths=[p for p in (r/'final').rglob('*.gz') if p.parent.name.endswith('-'+engine)];assert len(paths)==3
 row={'engine':engine}
 for p in paths:
  d=json.loads(gzip.decompress(p.read_bytes()))
  if 'differential' in p.name:
   assert len(d['rows'])==48 and len(d['counts'])==96
   for x in d['rows']:
    assert x['json']==x['packet'];a=[c for c in d['counts'] if c['lane']==x['lane'] and c['name']==x['name']];assert len(a)==2 and a[0]['bytes']==a[1]['bytes']
   nan=[x for x in d['rows'] if x['name']=='nan-dimensions'];assert len(nan)==4
   for x in nan:
    assert x['packet']['ok'];assert any((int(x['packet']['result'][k],16)&0x7ff0000000000000)==0x7ff0000000000000 and (int(x['packet']['result'][k],16)&0xfffffffffffff)!=0 for k in ['width','height'])
    assert any(c['lane']==x['lane'] and c['name']==x['name'] and c['mode']=='packet' and c['kind']=='packet' for c in d['counts'])
   row.update(differentialPairs=48,successPairs=sum(x['packet']['ok'] for x in d['rows']),nanPackets=[{k:x['packet']['result'][k] for k in ['width','height']} for x in nan],transportCountRecords=96)
  elif 'errors' in p.name:
   assert len(d)==14
   for x in d:
    assert x['json']==x['packet'];assert x['packet']['state']=={'cycle':True,'alias':True,'name':'changed'};assert x['packet']['repaired']['svg']
    if x['variant'].startswith('throw'):assert x['packet']['original']
    if x['variant']=='audit-with-limit':assert x['packet']['error']=={'name':'TypeError','message':'Accessor properties require an explicit public model codec'}
   row['errorLifecyclePairs']=14
  elif 'budget' in p.name:
   assert len(d)==4
   for israw in [False,True]:
    old=next(x for x in d if x['raw']==israw and x['mode']=='json');packet=next(x for x in d if x['raw']==israw and x['mode']=='packet');assert {**packet,'mode':'json'}==old;assert packet['calls']==1 and packet['repaired']==984
    if israw:
     assert packet['attempted']=={'success':True,'bytes':67108863};assert packet['error']['message']=='Public binary graph exceeds transport budget'
    else:assert packet['expectedBytes']==67108869 and packet['error']['message']=='Browser numeric transport exceeds byte budget'
   row['byteGates']={'envelopeRejectedBytes':67108869,'nativeSuccessBeforeGraphRejectionBytes':67108863,'ceiling':67108864}
 engines.append(row)
retained=[x for x in calc if x['case'].startswith('er/') and x['stage']=='render-model']
control=[x for x in calc if x not in retained]
result={'status':'passed frozen evidence audit; no new execution','evidenceRoot':str(r.relative_to(root)),'inputSHA256':{p:sha((r/p).read_bytes()) for p in ['comparison.json','source-freeze.json','evidence-index.json','paired-summary.json']},'archiveRecordsVerified':len(index['records']),'sourceCommit':freeze['sourceCommit'],'gitBackedInputsVerified':matched,'nativeSwiftSDKInputsVerified':len(sdk['inputHashes']),'completePackageFilesPerLane':106,'changedPackagePaths':[k for k in freeze['packageFiles'] if report['runtimeHashes']['control'][k]!=freeze['packageFiles'][k]],'conditions':24,'trialsPerLanePerCondition':21,'timedBatchSamples':24*21*3,'retainedER':retained,'adversePairedControls':[x for x in control if x['pairedMedianPercentChange']>0],'oppositeSignMedianVsPaired':[x for x in calc if (x['candidateOverControl']-1)*x['pairedMedianPercentChange']<0],'engines':engines,'fixtureVersions':{'frozenAt7339':freeze['sourceFiles']['web/tests/web/er-result-packet.spec.js'],'later4031':sha(subprocess.check_output(['git','show','4031a94:tests/web/er-result-packet.spec.js'],cwd=root)),'note':'Final9 artifacts prove strict overflow already. Freeze identifies7339 test;4031 is later test-only strict-overflow arithmetic, not claimed re-executed by this audit.'},'limitations':['Ordinary shared-page VM diagnostic; no per-row quiet guard or individual trial-order records.','Paired improvements scoped to retainedER; controls mixed; not JS parity/release gate.','No new native/Swift timings; exact prior351-input equality only.','Initial raw zero-vs13 graph admission threshold remains unexecuted; result-envelope gates do not close it.','Nonempty ER links unreachable.','Full369 suite belongs to precedingraw source; packet has45 existing+9 final focused checks.','Current lexer/frame package intentionally not used as identity source.']}
Path(__file__).with_name('AUDIT.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k in ['status','archiveRecordsVerified','gitBackedInputsVerified','nativeSwiftSDKInputsVerified','completePackageFilesPerLane','conditions','timedBatchSamples','changedPackagePaths']},indent=2))
