"""Read existing evidence; no benchmark, compiler, browser or consumer execution."""
from pathlib import Path
import collections, hashlib, json, math, subprocess
ROOT=Path(__file__).resolve().parents[4]
BASE=Path(__file__).resolve().parent
load=lambda p:json.loads(Path(p).read_text())
sha=lambda b:hashlib.sha256(b).hexdigest()
hashfile=lambda p:sha(Path(p).read_bytes())
q=lambda a,p:sorted(a)[max(0,math.ceil(len(a)*p)-1)]
def same(a,b):
 if isinstance(a,(int,float)) and isinstance(b,(int,float)): assert math.isclose(a,b,rel_tol=1e-12,abs_tol=1e-12),(a,b)
 else: assert a==b,(a,b)
def aggregate(d):
 # Match the executed JS localeCompare ordering exactly, without importing a runner.
 code="let s='';for await(const c of process.stdin)s+=c;const d=JSON.parse(s);process.stdout.write(Object.entries(d).sort(([a],[b])=>a.localeCompare(b)).map(([p,h])=>p+'\\0'+h+'\\0').join(''))"
 return sha(subprocess.check_output(['node','--input-type=module','-e',code],input=json.dumps(d).encode()))
def committed_inputs(revision,inputs):
 refs=[]; checks=[]; other=[]
 for key,digest in inputs.items():
  if key.startswith('root/'):path=key[5:]
  elif key.startswith('consumer/'):path='scripts/perf/swift/'+key[9:]
  elif key.startswith('web/'):path=key[4:]
  else:other.append(key);continue
  refs.append(f'{revision}:{path}');checks.append((key,digest))
 proc=subprocess.Popen(['git','cat-file','--batch'],cwd=ROOT,stdin=subprocess.PIPE,stdout=subprocess.PIPE)
 raw,_=proc.communicate(('\n'.join(refs)+'\n').encode()); pos=0; missing=[]
 for ref,(key,digest) in zip(refs,checks):
  end=raw.index(b'\n',pos);header=raw[pos:end];pos=end+1
  if header.endswith(b' missing'):missing.append(key);continue
  length=int(header.split()[-1]); data=raw[pos:pos+length];pos+=length+1
  assert sha(data)==digest,(ref,'frozen Git blob differs')
 assert proc.returncode==0
 return {'verifiedGitBlobs':len(checks)-len(missing),'notTrackedAtRevision':missing,'nonGitInputs':other}
sw=load(BASE/'runtime/swift-comparison-attempt1.json'); web=load(BASE.parent/'er-lexical-dispatch-first/comparison.json'); freeze=load(BASE/'runtime/source-freeze.json'); bm=load(BASE/'runtime/swift-build-manifest.json')
assert sw['completed'] and web['succeeded']; same(bm,sw['builds']['candidate']['manifest'])
assert freeze['sourceCommit']==bm['revision']==sw['revision']
same(freeze['nativeSourceInputSha256'],bm['sourceInputSha256']);same(freeze['packageFiles'],web['runtimeHashes']['candidate'])
for k,v in bm['inputHashes'].items():same(freeze['sourceFiles'][k],v)
identities={}
for side,b in sw['builds'].items():
 m=b['manifest'];same(aggregate(m['inputHashes']),m['sourceInputSha256'])
 manifest_path=BASE/'runtime/swift-build-manifest.json' if side=='candidate' else Path(b['manifestPath'])
 same(hashfile(manifest_path),b['manifestSha256']);same(load(manifest_path),m)
 same(hashfile(b['binary']),b['binarySha256']);same(b['binarySha256'],m['binarySha256'])
 identities[side]={'revision':m['revision'],'manifestSha256':b['manifestSha256'],'binarySha256':b['binarySha256'],'inputAggregate':m['sourceInputSha256'],'inputCount':len(m['inputHashes']),'historicalSourceVerification':committed_inputs(m['revision'],m['inputHashes'])}
# Current SDK/binary reads establish artifact identity only, never current source freshness.
same(hashfile(bm['nativeArchive']),bm['nativeHostArchiveSha256'])
same(hashfile(ROOT/'target'/bm['rustTarget']/'release/libpele_ffi.a'),bm['nativeHostArchiveSha256'])
identities['candidate']['actualSdkAndTargetArchiveSha256']=bm['nativeHostArchiveSha256']
for key,digest in bm['inputHashes'].items():
 if key.startswith('CPele/'):same(hashfile(ROOT/'bindings/swift/Artifacts/CPele.xcframework'/key[6:]),digest)
identities['candidate']['actualSdkFilesVerified']=13
ctrl=sw['builds']['control']['manifest']['inputHashes']; cand=bm['inputHashes']
changed=[{'path':k,'control':ctrl.get(k),'candidate':cand.get(k)} for k in sorted(set(ctrl)|set(cand)) if ctrl.get(k)!=cand.get(k)]
same(changed,sw['changedInputs'])
for k in ctrl:
 if k.startswith('consumer/'):same(ctrl[k],cand[k])
artifacts={}
for key,path,expected in [('swiftComparator','scripts/perf/swift/compare.mjs',sw['comparatorSha256']),('webComparator','scripts/perf/compare-web-vm.mjs',web['harnessSHA256']),('cases','scripts/perf/cases.mjs',web['casesSHA256']),('oracle','node_modules/pele/dist/pele.js',web['oracleSHA256']),('guardBuild','scripts/perf/swift/build.mjs',cand['consumer/build.mjs'])]:
 actual=hashfile(ROOT/path);same(actual,expected);artifacts[key]={'path':path,'sha256':actual}
same(sw['oracleSha256'],web['oracleSHA256']); same(sw['oracleRevision'],web['oracleRevision'])
workloads=json.loads(subprocess.check_output(['node','--input-type=module','-e',"import{cases}from'./scripts/perf/cases.mjs';process.stdout.write(JSON.stringify(cases()))"],cwd=ROOT))
workloads={x['id']:x for x in workloads}
expected={x['id']:x['expected'] for x in sw['cases']}
for c in sw['cases']:
 same(c['source'],workloads[c['id']]['source']);same(sha(c['source'].encode()),c['sourceSha256']);same(len(c['source'].encode()),c['sourceBytes'])
 for phase in ['before','after']:
  for side in ['control','candidate']:
   v=c[phase][side];same(v['caseID'],c['id']);same(len(v['outputs']),5)
   for output in v['outputs']:same(output,c['expected'])
  same(c[phase]['control'],c[phase]['candidate'])
orders=collections.Counter();guards=[];swift_rows=[];calibration_requests=0
for ri,r in enumerate(sw['rows']):
 assert len(r['raw'])==15; warm=r['warmup'];same(warm['control']['operations'],warm['candidate']['operations']);same(warm['control']['operations'],6+(warm['pairs']-6)*128)
 for side in ['control','candidate']:assert warm[side]['elapsedNs']>=1_000_000_000
 assert 1<=r['count']<=128
 for phase in [r['before'],r['after']]+r['calibration']+r['raw']:
  vals=phase['values'];same({k:v for k,v in vals['control'].items() if k!='elapsedNs'},{k:v for k,v in vals['candidate'].items() if k!='elapsedNs'})
  for side,v in vals.items():
   same(v['output'],expected[r['case']]);same(v['caseID'],r['case']);same(v['stage'],r['stage'])
   if 'elapsedNs' in v:
    assert isinstance(v['elapsedNs'],int) and v['elapsedNs']>0
    g=phase['guards'][side];assert g['at'];guards.append(g)
    assert not any(p['name'] in ['cargo','rustc','swiftc','swift-build','swift-frontend','xcodebuild','ld'] or(p['name']=='xctest' and p.get('testScope')=='pele') for p in g['externalLoad'])
 for i,p in enumerate(r['calibration']):
  same(p['values']['control']['count'],min(128,2**i));calibration_requests+=2
 same(r['calibration'][-1]['values']['control']['count'],r['count'])
 final=r['calibration'][-1]['values'];assert r['count']==128 or max(v['elapsedNs'] for v in final.values())>=12_000_000
 for ti,p in enumerate(r['raw']):
  same(p['trial'],ti);same(p['order'],['control','candidate'] if (ri+ti+sw['settings']['orderOffset'])%2==0 else ['candidate','control']);orders[p['order'][0]]+=1
  for v in p['values'].values():same(v['count'],r['count'])
 c=[p['values']['control']['elapsedNs']/r['count']/1e6 for p in r['raw']];a=[p['values']['candidate']['elapsedNs']/r['count']/1e6 for p in r['raw']];ratios=[x/y for x,y in zip(a,c)];st=r['statistics'];med=q(ratios,.5)
 for key,vals in [('controlMs',c),('candidateMs',a),('ratios',ratios),('pairedPercentChanges',[(x-1)*100 for x in ratios])]:
  for x,y in zip(st[key],vals):same(x,y)
 stats={'median':med,'mad':q([abs(x-med) for x in ratios],.5),'min':min(ratios),'max':max(ratios),'sampleP95':q(ratios,.95)}
 for k,v in stats.items():same(st['pairedCandidateOverControl'][k],v)
 same(st['ratioOfMedians'],q(a,.5)/q(c,.5));same(st['candidateFasterPairs'],sum(x<1 for x in ratios))
 swift_rows.append({'case':r['case'],'stage':r['stage'],'count':r['count'],'controlMedianMs':q(c,.5),'candidateMedianMs':q(a,.5),'pairedPercent':(med-1)*100,'ratioOfMediansPercent':(q(a,.5)/q(c,.5)-1)*100,'wins':sum(x<1 for x in ratios),'warmup':warm})
same(dict(orders),sw['orderCounts']);same(dict(orders),{'control':45,'candidate':45})
web_rows=[]
for r in web['rows']:
 samples=r['samples'];assert all(len(v)==21 for v in samples.values());same(r['counts']['control'],r['counts']['candidate']);assert all(1<=v<=128 and v&(v-1)==0 for v in r['counts'].values())
 for name,values in samples.items():
  assert all(x>0 and math.isfinite(x) for x in values);same(q(values,.5),r['medianMs'][name]);same(q(values,.95),r['p95BatchMeanMs'][name]);assert r['warmups'][name]['elapsedMs']>=1000 and r['warmups'][name]['operations']>=6
 for ratio,num,den in [('candidateOverControl','candidate','control'),('candidateOverJS','candidate','js'),('controlOverJS','control','js')]:same(r[ratio],r['medianMs'][num]/r['medianMs'][den])
 ratios=[a/c for a,c in zip(samples['candidate'],samples['control'])]
 web_rows.append({'case':r['case'],'profile':r['profile'],'stage':r['stage'],'pairedPercent':(q(ratios,.5)-1)*100,'ratioOfMediansPercent':(r['candidateOverControl']-1)*100,'wins':sum(x<1 for x in ratios),'candidateOverJS':r['candidateOverJS'],'counts':r['counts']})
for c in web['cases']:
 source=workloads[c['id']]['source'].encode();same(sha(source),c['sourceSHA256']);same(len(source),c['sourceBytes']);same({x['profile'] for x in c['checks']},{'fixed','canvas'})
vm_orders=[]
for trial in range(21):
 names=['js','control','candidate'];o=names[trial%3:]+names[:trial%3]
 if (trial//3)%2:o.reverse()
 vm_orders.append(o)
first=collections.Counter(o[0] for o in vm_orders);precedence=collections.Counter('control' if o.index('control')<o.index('candidate') else 'candidate' for o in vm_orders)
control_freeze=load(BASE.parent/'er-result-packet/runtime/source-freeze.json');same(control_freeze['packageFiles'],web['runtimeHashes']['control'])
package_evidence={'controlRecordedFiles':len(web['runtimeHashes']['control']),'candidateRecordedFiles':len(web['runtimeHashes']['candidate']),'controlMatchesResultPacketFreeze':True,'candidateMatchesLexicalFreeze':True,'changedFiles':[k for k,v in web['runtimeHashes']['candidate'].items() if web['runtimeHashes']['control'].get(k)!=v],'physicalHistoricalPackageVerification':'pending immutable mirror; never substitute current package','frozenSourceVerification':committed_inputs(freeze['sourceCommit'],freeze['sourceFiles'])}
rehash_path=BASE.parent/'er-lexical-dispatch-first/independent-vm-rehash.json'
rehash=load(rehash_path)
same(rehash['runtimeHashes'],web['runtimeHashes'])
assert rehash['verifiedAt']>web['completedAt']
package_evidence['physicalHistoricalPackageVerification']={'status':'all 106 files per side match fresh post-timing remote byte rehash','verifiedAt':rehash['verifiedAt'],'roots':rehash['roots'],'evidencePath':str(rehash_path.relative_to(ROOT)),'evidenceSha256':hashfile(rehash_path),'method':'Parent independently walked both frozen VM directories with a fresh Node SHA reader over SSH, separate from benchmark scripts. Reviewer compared every resulting path/hash to report and frozen manifests.','limit':'File bodies were not downloaded; this verifies the supplied independent remote byte-reading record, not a second local rehash or uninterrupted monitoring.'}
processes={}
for g in guards:
 for p in g['externalLoad']:
  key=p['name'];processes[key]=max(processes.get(key,0),p['cpuPercent'])
out={'scope':'Existing evidence audit only; no benchmark/build/browser/consumer execution. Runtime source checked from frozen Git objects, not current worktree.','reportHashes':{str(p.relative_to(ROOT)):hashfile(p) for p in [BASE/'runtime/swift-comparison-attempt1.json',BASE/'runtime/source-freeze.json',BASE/'runtime/swift-build-manifest.json',BASE.parent/'er-lexical-dispatch-first/comparison.json']},'artifactIdentities':identities,'harnessIdentities':artifacts,'changedSwiftInputs':changed,'swift':{'rows':swift_rows,'pairs':90,'firstOrderCounts':dict(orders),'storedTimedRequestGuards':len(guards),'calibrationRequests':calibration_requests,'maximumRecordedCpuByProcessName':processes,'guardLimitation':'Rejects build/Pele test processes, allows other recorded desktop load; warmup has aggregate counts/durations but no saved individual guard records.'},'web':{'rows':web_rows,'triples':504,'settings':web['settings'],'perRowFirstCountsDerivedFromHashVerifiedHarness':dict(first),'perRowControlCandidatePrecedenceDerived':dict(precedence),'orderLimitation':'Report saves samples per lane but no observed raw order or timer start/end; ordering derived from immutable verified harness.','guardLimitation':'No per-row quiet process guard in this comparator. Load/memory only before/after; ten-minute deadline and package before/after identity assertions.','correctness':'Harness checks complete SVG and Object.is dimensions for retained/source/fresh parse before and after; report stores case/profile SVG byte counts, not full outputs.','packages':package_evidence},'limitations':['Swift is a combined df3597c versus 0b32797 binary comparison, not isolated lexer causality.','Shared desktop load and one-page VM heap/GC remain; no confidence interval or regression absence inferred.','These diagnostic results are not the complete release gate or JS parity.']}
(BASE/'audit.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'swiftRows':len(swift_rows),'webRows':len(web_rows),'orders':dict(orders),'identities':identities,'packageEvidence':package_evidence,'maxRecordedCpu':processes},indent=2))
